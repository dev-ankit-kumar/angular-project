import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SeatService {
  seats: { id: number; row: number; isBooked: boolean }[] = [];

  constructor() {
    // Initialize 80 seats (11 rows with 7 seats, last row with 3 seats)
    for (let i = 0; i < 11; i++) {
      for (let j = 1; j <= 7; j++) {
        this.seats.push({ id: i * 7 + j, row: i + 1, isBooked: false });
      }
    }
    for (let j = 1; j <= 3; j++) {
      this.seats.push({ id: 77 + j, row: 12, isBooked: false });
    }
  }

  getAvailableSeats() {
    return this.seats.filter((seat) => !seat.isBooked);
  }

  bookSeats(count: number): number[] {
    const availableSeats = this.getAvailableSeats();
    let bookedSeats: number[] = [];

    // Try to book seats in the same row
    for (let i = 1; i <= 12; i++) {
      const rowSeats = availableSeats.filter((seat) => seat.row === i);
      if (rowSeats.length >= count) {
        bookedSeats = rowSeats.slice(0, count).map((seat) => seat.id);
        break;
      }
    }

    // If no single row has enough seats, book the nearest available seats
    if (bookedSeats.length === 0) {
      bookedSeats = availableSeats.slice(0, count).map((seat) => seat.id);
    }

    // Mark the seats as booked
    bookedSeats.forEach((id) => {
      const seat = this.seats.find((s) => s.id === id);
      if (seat) seat.isBooked = true;
    });

    return bookedSeats;
  }

  getSeatStatus() {
    return this.seats;
  }
}
